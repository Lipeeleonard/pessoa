<html>
    <body>
    <hr/>

        <center><h3> CRUD PHP</h3></center>
        <hr/>
        <form action="index.php" method="POST">/<center>
        <center>  <label>Nome</label><br/></center>
        <center><input type="text" name = "nome" required/><br/></center>
        <center><label>Idade</label><br/></center>
        <center><input type="number" name = "idade" required/><br/><br/></center>
        <center> <input type="submit" value = "Inserir" name = "btinserir"/><br/><br/><br/></center>

        </form>
        <?php
        if(isset($_POST['btinserir'])){
            include 'conecta.php';
            $nome = $_POST['nome'];
            $idade = $_POST['idade'];
            $sql = "INSERT INTO pessoa(nome,idade) VALUES('$nome','$idade')";
            if(mysqli_query($conn,$sql)){
                echo "<script language='javascript' type='text/javascript'>
                alert('registro inserido com sucesso!');
                window.location.href='index.php'
                </script>";
            }else{
                echo "<script language='javascript' type='text/javascript'> 
                alert('registro falhou!');
                window.location.href='index.php'
                </script>";
            }
            mysqli_close($conn);
        }else{
            echo "";
        }
        ?>
        <hr/>
        <table border="1">
        <tr>
        <td>ID</td>
        <td>Nome</td>
        <td>Idade</td>
        <td>Ações</td>
        </tr>
        <?php
            include 'conecta.php';
            $pessoa = mysqli_query($conn, "SELECT * FROM pessoa");
            $linha = mysqli_num_rows($pessoa);
            if($linha>0){
                while ($registro =$pessoa->fetch_array()){
                    echo'<tr>';
                        echo '<td>'.$registro['id'].'</td>';
                        echo '<td>'.$registro['nome'].'</td>';
                        echo '<td>'.$registro['idade'].'</td>';
                        echo '<td>Editar | <a href="exclui.php?id='.$registro['id'].'">Excluir</a></td>';
                    echo'</tr>';
                }

            }else{
                echo "Não há registros para listar!";
            }
            mysqli_close($conn);
        ?>
        </table>
    </body>
</html>